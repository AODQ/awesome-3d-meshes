# Breakfast Room

![image](https://casual-effects.com/g3d/data10/research/model/breakfast_room/icon.png)

Exported from Blender to OBJ and materials and geometry corrected by Morgan McGuire. First used for 3D graphics research by Bitterli. 
Geometry downloaded from [here](http://www.blendswap.com/blends/view/75431). Marble texture is public domain from [here](https://hugolj.deviantart.com/art/White-Marble-Texture-500949943).    


Triangles: 808,622\
Vertices: 166,211\
Updated: 2017-09-27\
License: [CC BY 3.0](https://creativecommons.org/licenses/by/3.0/)\
[© Wig42](http://www.blendswap.com/user/Wig42)