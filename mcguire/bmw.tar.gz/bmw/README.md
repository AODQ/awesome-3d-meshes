# BMW

![image](https://casual-effects.com/g3d/data10/research/model/bmw/icon.png)

Mike Pan created this model for a [Blender 2.7 demo](https://www.blender.org/download/demo-files/). Morgan McGuire corrected exposed backfaces, most holes, mesh interpenetration, and materials in 3DS Max and exported to OBJ format. The original had two cars with angled wheels. This version has a single car with wheels in a default pose that for easier run-time animation.    


Triangles: 385079\
Vertices: 249772\
Updated: 2019-04-17\
License: CC0/Public Domain\
Mike Pan and Morgan McGuire