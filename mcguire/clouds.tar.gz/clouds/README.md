# Clouds

![image](https://casual-effects.com/g3d/data10/research/model/cloud/icon.png)

Five polygonal cloud shell models created using SculptGL which first appeared in [McGuire and Mara, Phenomenological Transparency, 
IEEE Transactions of Visualization and Computer Graphics, no. 5, May, 2017](http://casual-effects.com/research/McGuire2017Transparency/index.html).    


Triangles: undefined\
Vertices: undefined\
Updated: 2017-07-02\
License: [CC0](https://creativecommons.org/publicdomain/zero/1.0/)\
© 2016 Morgan McGuire and Michael Mara